<?php
include_once("db.php");
include_once("config.php");
include_once("func.php");

if (isset($_POST['username']) && isset($_POST['password'])) {
  $username = $_POST['username'];
  $password = $_POST['password'];

  if (waf1($username) && waf1($password)) {
    $db = new DB($c['host'], $c['user'], $c['pass'], $c['db']);

    $sql = "select * from users where username='$username' and password='$password';";
    $result = $db->query($sql);
    if (gettype($result) === 'boolean') {
      redirect("Something Error!", "login.php");
    }
    else {
     if (count($result) > 0 && sha1($result[0]["password"]) === sha1($password)) {
        $_SESSION['login'] = True;
        $_SESSION['username'] = $result[0]['username'];
        $_SESSION['power'] = $result[0]['power'];
        redirect("Welcome, ".$_SESSION['username'], "index.php");
      }
      else {
        redirect("username or password error!", "login.php");
      }     
    }
  }
  else {
    redirect("Hacker!", "login.php");
  }
}

?>


<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta ip="<?php echo $_SERVER['SERVER_NAME'];?>">
  <meta port="<?php echo $_SERVER['SERVER_PORT'];?>">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Calc</title>
  <style>
    body {
      background: url('bg.jpg') no-repeat;
      background-size: 100% 130%;
    }

    #login_box {
      width: 20%;
      height: 400px;
      background-color: #00000060;
      margin: auto;
      margin-top: 10%;
      text-align: center;
      border-radius: 10px;
      padding: 50px 50px;
    }

    h2 {
      color: #ffffff90;
      margin-top: 5%;
    }

    #input-box {
      margin-top: 5%;
    }

    span {
      color: #fff;
    }

    input {
      border: 0;
      width: 60%;
      font-size: 15px;
      color: #fff;
      background: transparent;
      border-bottom: 2px solid #fff;
      padding: 5px 10px;
      outline: none;
      margin-top: 10px;
    }

    button {
      margin-top: 50px;
      width: 60%;
      height: 30px;
      border-radius: 10px;
      border: 0;
      color: #fff;
      text-align: center;
      line-height: 30px;
      font-size: 15px;
      background-image: linear-gradient(to right, #30cfd0, #330867);
    }

    #sign_up {
      margin-top: 45%;
      margin-left: 60%;
    }

    a {
      color: #b94648;
    }
  </style>
</head>

<body>
  <div id="login_box">
    <h2>Login</h2>
    <form action="login.php" method="POST">
      <div id="input_box">
        <input type="text" placeholder="username" name="username">
      </div>
      <div class="input_box">
        <input type="password" placeholder="password" name="password">
      </div>
      <button type="submit">Login</button><br>
    </form>
  </div>
</body>
</html>
