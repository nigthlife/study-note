<?php
include_once("func.php");

if (!isset($_SESSION['login']) || !$_SESSION['login']) {
    redirect("Login First!", "login.php");
}

if (isset($_GET['hint'])) {
    echo file_get_contents("hint.txt");
}

$num = "0";
$q = False;

if (isset($_POST['num'])) {
  $num = $_POST['num'];
  if (waf2($num)) {
    if (!isset($_SESSION['power']) || !$_SESSION['power']) {
      $num = "No qualification!";
    }
    else {
      $q = True;
    }
  } else {
    $num = "No No No!!!";
  } 
}
?>


<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta ip="<?php echo $_SERVER['SERVER_NAME'];?>">
  <meta port="<?php echo $_SERVER['SERVER_PORT'];?>">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Calc</title>
  <style>
    body {
      background: url('bg.jpg') no-repeat;
      background-size: 100% 130%;
    }

    #login_box {
      width: 20%;
      height: 400px;
      background-color: #00000060;
      margin: auto;
      margin-top: 10%;
      text-align: center;
      border-radius: 10px;
      padding: 50px 50px;
    }

    h2 {
      color: #ffffff90;
      margin-top: 5%;
    }

    #input-box {
      margin-top: 5%;
    }

    span {
      color: #fff;
    }

    input {
      border: 0;
      width: 60%;
      font-size: 15px;
      color: #fff;
      background: transparent;
      border-bottom: 2px solid #fff;
      padding: 5px 10px;
      outline: none;
      margin-top: 10px;
    }

    button {
      margin-top: 50px;
      width: 60%;
      height: 30px;
      border-radius: 10px;
      border: 0;
      color: #fff;
      text-align: center;
      line-height: 30px;
      font-size: 15px;
      background-image: linear-gradient(to right, #30cfd0, #330867);
    }

    #sign_up {
      margin-top: 45%;
      margin-left: 60%;
    }

    a {
      color: #b94648;
    }
  </style>
</head>

<body>
  <div id="login_box">
    <h2>Calc</h2>
    <form action="index.php" method="POST">
      <div id="input_box">
        <input type="text" placeholder="num" name="num">
      </div>
      <button type="submit">Submit</button><br>
    </form>
    <!-- /?hint -->
    Result: <p><?php if ($q) {@eval('echo '.$num.';');} else {echo $num;};?></p>
  </div>
</body>
</html>
