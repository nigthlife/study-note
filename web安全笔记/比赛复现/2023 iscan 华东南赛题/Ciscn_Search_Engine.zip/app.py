from flask import *
import os
from waf import waf
import re

app = Flask(__name__)

pattern = r'([0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}):([0-9]{2,5})'
content = '''<!doctype html>
<html lang="zh">
<head>
<meta charset="UTF-8">
<meta ip="%s">
<meta port="%s">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"> 
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Ciscn Search Engine</title>
</head>
<body>
<div class="htmleaf-container">
	<div class="wrapper">
		<div class="container">
			<h1>Ciscn Search Engine</h1>
			<form class="form" method="post" action="/" id="Form">
				<input name="word" type="text" placeholder="word">
				<button type="submit" id="login-button">Search</button>
			</form>
		</div>
		<ul class="bg-bubbles">
			<li>%s</li>
		</ul>
	</div>
</body>
</html>'''

@app.route("/", methods=["GET", "POST"])
def index():
	ip, port = re.findall(pattern,request.host).pop()
	if request.method == 'POST' and request.form.get("word"):
		word = request.form.get("word")
		if not waf(word):
			word = "Hacker!"
	else:
		word = ""

	return render_template_string(content % (str(ip), str(port), str(word)))


if __name__ == '__main__':
	app.run(host="0.0.0.0", port=int(os.getenv("PORT")))
