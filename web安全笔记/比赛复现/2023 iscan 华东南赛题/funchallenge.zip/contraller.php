<?php
show_source(__FILE__);
error_reporting(0);

class MySQL
{
    // 连接
    public $conn = null;
    protected $config = array(
        "dsn"      => "mysql:host=localhost:3306;dbname=?",
        "username" => "wow",
        "password" => "wow123"
    );
    // 创建数据连接
    public function __construct()
    {
        $this->conn = new PDO($this->config['dsn'], $this->config['username'], $this->config['password']);
    }
}

class Resume
{
    public $name;
    public $sql;
    public $stmt;
    public $id;
    public $data = array();
    public $conn = null;

    // 获取连接
    public function __construct()
    {
        $mysql = new MySQL();
        $this->conn = $mysql->conn;
    }

    // 显示articles表所有数据
    public function show()
    {
        try {
            $sql = 'select * from articles;';
            $stmt = $this->conn->prepare($sql);
            $stmt->execute();
            while ($row = $stmt->fetch(PDO::FETCH_BOTH)) {
                $this->data[] = $row;
            }
            $this->conn = null;
            return $this->data;
        } catch (Exception $e) {
            $this->conn = null;
        }
    }

    // 搜索
    public function query($title)
    {
        try {
            $sql = " SELECT * FROM `articles` WHERE `title` LIKE :name ";
            $stmt=$this->conn->prepare($sql);
            $stmt->bindValue(':name', '%'.$title.'%', PDO::PARAM_STR);
            $stmt->execute();
            $row = $stmt->fetchAll(PDO::FETCH_ASSOC);
            $this->conn = null;
            return $row;
        } catch (Exception $e) {
            $this->conn = null;
        }
    }
}

class AAA 
{
    public $name;
    public $sql;
    public $stmt;
    public $id;
    public $data = array();
    public $conn = null;
    public function __construct()
    {
        $mysql = new MySQL();
        $this->conn = $mysql->conn;
    }

    // 
    public function query($title)
    {
        $sql = "SELECT * FROM `articles` WHERE `title` LIKE '%' '".$title."' '%';";
        if (preg_match('/\b(???)\b/i',$title)) {
            die('hack!');
        }
        $stmt = $this->conn->query($sql);
        $this->conn = null;
    }
}
class BBB{
    protected $a;
    protected $func;
    public function __toString()
    {
        $b = $this->a;
        return (string)$b();
    }
}
class CCC{
    public $a;
    public $b;
    public $c;
    public function __invoke(){
        if(($this->a != $this->b) && (md5($this->a) == md5($this->b))){
            $func = new AAA();
            $func->query($this->c);
        }
    }
}
class DDD{
    public $a;
    public function func($checksec)
    {
        if ($checksec == 0) {
            return 'NOPE';
        }
        return 'OK';
    }
    public function __set($name, $value){
        $this->$name = $this->a;
        echo $this->a;
    }
}

class EEE
{
    public $a;
    public $b;
    public function __call($name, $argc){
        $this->b->func = $argc[0];
    }
    public function calculate($arg1, $arg2)
    {
        $c = $arg1 + $arg2;
        return $c;
    }
    public function __wakeup(){
        $this->a->helloworld = $this->b;
    }
}

unserialize($_POST['sql']);

$e = new EEE();
$d = new DDD();
$a = new AAA();
$b = new BBB();
$c = new CCC();
$e->a = $d;
$e->b =  $d;
$b->a = $c;
$d->a = $b;
