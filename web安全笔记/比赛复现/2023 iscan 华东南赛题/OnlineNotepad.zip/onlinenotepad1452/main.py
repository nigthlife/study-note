import os
import jinja2
import uvicorn
import hashlib
from pydantic import BaseModel, Field, validator
from fastapi import FastAPI, Request
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates


app = FastAPI()

userinfo_path = "userinfo"
note_path = "note"

app.mount("/static", StaticFiles(directory="static"), name="static")
templates = Jinja2Templates(directory=["templates", userinfo_path, note_path])


userinfo_raw = """{%% set userid = "%s" %%}"""

notefile_raw = """<html>
<head>
    <title>Online Notepad</title>
    <link href="{{ url_for('static', path='/styles.css') }}" rel="stylesheet">
</head>
<body>
<div>
    {%% import userid+".j2" as user %%}
        <h1>Hello {{ userid }}</h1>
        <h1><pre>{%% raw %%}%s{%% endraw %%}</pre></h1>
</div>
</body>
</html>
"""

class Note(BaseModel):
    userid: str = Field(min_length=5, max_length=20)
    note: str = Field(min_length=1, max_length=64)

    @validator("userid")
    def val_userid(cls, v):
        if v.isalnum() != True:
            raise ValueError("userid cannot contain a special character")
        return v

    @validator("note")
    def val_note(cls, v):
        if ("{{" in v) or ("}}" in v):
            raise ValueError("note cannot contain a special character")
        return v


@app.post("/note/")
async def write_note(request:Request, note:Note):
    global userinfo_path, note_path
    global userinfo_raw, notefile_raw

    userinfo = userinfo_raw % (note.userid)
    open(os.path.join(userinfo_path, note.userid+".j2"), "w").write(userinfo)

    notefile = notefile_raw % note.note
    open(os.path.join(note_path, note.userid+".html"), "w").write(notefile)

    return note

@app.get("/note/{userid}")
async def read_note(request:Request, userid:str):
    global userinfo_path, note_path
    global userinfo_raw, notefile_raw

    try:

        if (
            (userid.isalnum() == True) and 
            os.path.exists( os.path.join(userinfo_path, userid+".j2") ) and 
            os.path.exists( os.path.join(note_path, userid+".html") )
        ):
            return templates.TemplateResponse(userid+".html", {"request": request, "userid":userid})
        else:
            return templates.TemplateResponse("readfail.html", {"request": request})
    except Exception as e:
        print(e)
        return("Exception")

@app.get('/')
async def index(request:Request):
    context = {"request":request}
    return templates.TemplateResponse('index.html', context)


if __name__ == '__main__':
    uvicorn.run(app, host="0.0.0.0", port=80, headers=[("Server", "FastAPI")], log_level="info")