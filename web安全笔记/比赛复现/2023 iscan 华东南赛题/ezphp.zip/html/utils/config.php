<?php
    libxml_disable_entity_loader(false);
    return  array(
    "user_info_dir" => "/tmp/users/"
    );