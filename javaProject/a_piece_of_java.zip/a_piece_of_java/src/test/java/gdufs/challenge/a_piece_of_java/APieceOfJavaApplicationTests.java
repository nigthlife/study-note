package gdufs.challenge.a_piece_of_java;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class APieceOfJavaApplicationTests {

	@Test
	void contextLoads() {
	}

}
