

[TOC]



## 1、Spring简介

-   Spring：春天 ---> 给软件行业带来了春天
-   2002,首次推出了Spring框架的雏形: interface21框架!
-   Spring框架即以interface21框架为基础,经过重新设计 ,并不断丰富其内涵,于2004年月24日，发布了1.0正式版。
-   Spring以IOC（反转控制）赫尔AOP（面向切面编程）为内核
-   Spring提供了展现SpringMV和持久层Spring JDBCTemplate以及业务层事务管理等众多的企业级应用技术
-   **Rod Johnson**，Spring Framework创始人， 著名作者。很难想象Rod Johnson的学历， 真的让好多人大吃一
    惊，他是悉尼大学的博士,然而他的专业不是计算机，而是音乐学。
-   **Spring理念: 使现有的技术更加容易使用，本身是一个大杂烩， 整合了现有的技术框架!**
-   SSH : Struct2 + Spring + Hibernate! (以前) 
-   SSM : SpringMvc + Spring + Mybatis!  

Spring => **轻量级开源框架**

官网：https://spring.io/projects/spring-framework#learn

下载地址：https://repo.spring.io/release/org/springframework/spring/

GitHub地址：https://github.com/spring-projects/spring-framework

官方文档：https://docs.spring.io/spring-framework/docs/current/reference/html/core.html#spring-core

**maven仓库地址**

![image-20210303153513429](G:\各科笔记\Spring笔记\Spring.assets\image-20210303153513429.png)

```xml
<properties>
    <spring.version>5.0.5.RELEASE</spring.version>
</properties>
<!--导入spring的context坐标，context依赖core、beans、expression-->
<dependencies> 
    <dependency>  
        <groupId>org.springframework</groupId> 
        <artifactId>spring-context</artifactId> 
        <version>${spring.version}</version>
    </dependency>
</dependencies>

<!-- Maven地址 -->
<!-- https://mvnrepository.com/artifact/org.springframework/spring-aop -->
<dependency>
    <groupId>org.springframework</groupId>
    <artifactId>spring-aop</artifactId>
    <version>5.2.0.RELEASE</version>
</dependency>
```



1、优点

-   Spring是一个开源的免费的框架（容器！）

-   Spring是一个轻量级的、非入侵式的框架，也就是导入它并不会对你项目产生影响

-   特性：控制反转（IOC） ， 面向切面编程（AOP）

-   支持事务的处理，对框架的整合支持

-   方便解耦，简化开发

    >    通过 Spring 提供的 IoC容器，可以将对象间的依赖关系交由 Spring 进行控制，避免硬编码所造成的过度耦合。用户也不必再为单例模式类、属性文件解析等这些很底层的需求编写代码，可以更专注于上层的应用。

-   方便集成各种优秀框架

    >   对各种优秀框架（Struts、Hibernate、Hessian、Quartz等）的支持

-   降低JavaEE API 的使用难度

    >   对 JavaEE API（如 JDBC、JavaMail、远程调用等）进行了薄薄的封装层，使这些 API 的使用难度大为降低

-   



**总结：Spring就是一个轻量级的控制反转（IOC） 和 面向切面编程（AOP）的框架**



#### 2、组成(体系)

![image-20210309093510518](G:\各科笔记\Spring笔记\Spring.assets\image-20210309093510518.png)

![image-20210312085645481](G:\各科笔记\Spring笔记\Spring.assets\image-20210312085645481.png)

#### 3、[扩展](##1、Spring简介)



![image-20210309093754486](G:\各科笔记\Spring笔记\Spring.assets\image-20210309093754486.png)



-   Spring Boot
    -   一个快速开发的脚手架
    -   基于SpringBoot可以快速的开发单个微服务
    -   约定大于配置
-   Spring Cloud
    -   SpringCLoud是基于SpringBoot实现的



因为现在大多数公司都在使用SpringBoot进行快速开发，学习SpringBoot的前提， 需要完全掌握Spring及
SpringMVC!  



**Spring弊端:发展了太久之后，违背了原来的理念!配置十分繁琐,人称:”配置地狱!”**



## [2、IOC理论推导](##1、Spring简介)

 1、UserDao 接口

```java
public interface UserDao {

    void getUser();
}

```

 2、UserDaoImpl 实现类

```java
public class UserDaoImpl implements UserDao {
    public void getUser() {
        System.out.println("默认获取用户的数据");
    }
}

public class UserDaoMysqlImpl implements UserDao {
    public void getUser() {
        System.out.println("通过MySQL获取数据");
    }
}

public class UserDaoOracleImpl implements UserDao{
    public void getUser() {
        System.out.println("从Oracle中获取数据");
    }
}

```

 3、UserService 业务接口

```java
public interface UserService {

    void getUser();
}
```

 4、UserServiceImpl 业务接口实现类

```java
public class UserServiceImpl implements UserService {

    // 使用组合
    private UserDao userDao = new UserDaoImpl();

    public void setUserDao(UserDao userDao) {
        this.userDao = userDao;
    }

    public void getUser() {
        userDao.getUser();
    }
}
```



在我们之前的业务中，用户的需求可能会影响我们原来的代码，我们需要根据用户的需求去修改原代码!如果程序代码量十分大，修改- -次的成本代价十分昂贵!|

我们使用一个set接口实现，已经发生了革命性的变化

```java
public class UserServiceImpl implements UserService {

    // 使用组合
    private UserDao userDao = new UserDaoImpl();

    public void setUserDao(UserDao userDao) {
        this.userDao = userDao;
    }

    public void getUser() {
        userDao.getUser();
    }
}
```

-   之前，程序是主动创建对象！控制权在程序员手上
-   使用set注入后，程序不再具有主动性，而是变成了被动的接受对象
-   这就是控制反转（IOC）

**这种思想，从本质上解决了问题，不用在去管理对象，系统的耦合性大大降低，可以更加专注在业务上**,

**这就是IOC的原型**

**[测试](##1、Spring简介)**

```java
import com.wlp.dao.UserDaoImpl;
import com.wlp.service.UserServiceImpl;
import com.wlp.service.UserService;

/**
 * 功能：
 *
 * @author 武乐萍
 * @modifier 武乐萍
 * @date 2021-03-09 14:27
 * @Version V1.0
 */
public class MyTest {

    public static void main(String[] args) {

        UserService userSercice = new UserServiceImpl();

        ((UserServiceImpl)userSercice).setUserDao(new UserDaoImpl());

        userSercice.getUser();
    }
}

```





#### **1、[I0C本质](##1、Spring简介)**

**控制反转**loC(Inversion of Control),是一种设计思想，DI(依赖注入)是实现IoC的一种方法，也有人认为DI只是IoC的另一种说法。没有IoC的程序中,我们使用面向对象编程,对象的创建与对象间的依赖关系完全硬编码在程序中，对象的创建由程序自己控制，控制反转后将对象的创建转移给第三方，个人认为所谓控制反转就是:获得依赖对象的方式反转了。



采用XML方式配置Bean的时候，Bean的定义信息是和实现分离的，而采用注解的方式可以把两者合为一体,Bean的定义信息直接以注解的形式定义在实现类中，从而达到了零配置的目的。



**控制反转是一种通过描述(XML或注解)并通过第三方去生产或获取特定对象的方式。在Spring中实现控制反
转的是IoC容器，其实现方法是依赖注入(Dependency Injection,DI)。**



#### 2**、[hello Spring](##1、Spring简介)**

##### 1、xml文件配置

```xml
<?xml version="1.0" encoding="UTF-8"?>
<beans xmlns="http://www.springframework.org/schema/beans"
       xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
       xsi:schemaLocation="http://www.springframework.org/schema/beans
       http://www.springframework.org/schema/beans/spring-beans.xsd">

    <!-- 将创建对象的交给Spring来管理 -->
    <bean id="Impl" class="com.wlp.dao.UserDaoImpl" />
    <bean id="MysqlImpl" class="com.wlp.dao.UserDaoMysqlImpl" />
    <bean id="oracle" class="com.wlp.dao.UserDaoOracleImpl" />

    <!-- 创建业务层对象 -->
    <bean id="service" class="com.wlp.service.UserServiceImpl">
        <property name="userDao" ref="MysqlImpl"></property>
     </bean>
    <!--
        ref ：传入已经被Spring管理的beanid
        values：传入基本数据类型的值
     -->
</beans>
```

##### **2、[测试](##1、Spring简介)**

```java
import com.wlp.dao.UserDaoImpl;
import com.wlp.dao.UserDaoMysqlImpl;
import com.wlp.service.UserServiceImpl;
import com.wlp.service.UserService;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * 功能：
 *
 * @author 武乐萍
 * @modifier 武乐萍
 * @date 2021-03-09 14:27
 * @Version V1.0
 */
public class MyTest {

    public static void main(String[] args) {

        // 获取ApplicationContext对象，拿到Spring容器
        ApplicationContext context = new ClassPathXmlApplicationContext("beans.xml");

        // 需要执行哪个业务实现就get哪个
        UserDaoMysqlImpl mysqlImpl = (UserDaoMysqlImpl) context.getBean("MysqlImpl");

        // 获取用户数据
        mysqlImpl.getUser();
    }
}

```



思考问题?

-   Hello对象是谁创建的?
-   hello对象是由Spring创建的
-   Hello对象的属性是怎么设置的?
-   hello对象的属性是由Spring容器设置的，



-   **这个过程就叫控制反转:**

    -   **控制**: 谁来控制对象的创建,传统应用程序的对象是由程序本身控制创建的,使用Spring后,对象是由Spring来创
        建的.
    -   **反转**: 程序本身不创建对象,而变成被动的接收对象.
    -   **依赖注入**: 就是利用set方法来进行注入的.
    -   **I0C是一种编程思想,由主动的编程变成被动的接收.**

    -   可以通过**new ClassPathXmlApplicationContext**去浏览一下底层源码 .

    

    **OK ,到了现在,我们彻底不用再程序中去改动了,要实现不同的操作,只需要在xmI配置文件中进行修改,所谓的**
    **loC,一句话搞定:对象由Spring来创建,管理, 装配!**



#### 3、[IOC创建对象的方法](##1、Spring简介)

**默认使用无参构造创建对象，默认**

##### 使用有参构造创建对象

​	**1、下标赋值**

```xml
<!-- 第一种：下标赋值！ -->
<bean id="user" class="com.wlp.pojo.user">
    <constructor-arg index="0" value="java" />
</bean>

<!-- 官方案例 -->
<bean id="exampleBean" class="examples.ExampleBean">
    <constructor-arg index="0" value="7500000"/>
    <constructor-arg index="1" value="42"/>
</bean>
```

​	**2、[类型](##1、Spring简介)**

```xml
<!-- 第二种方式：通过类型创建，如果参数为俩个且都是同一类型，就不好搞 -->
<bean id="user" class="com.wlp.pojo.user">
    <constructor-arg type="java.lang.String" value="java" />
</bean>

<!-- 官方案例 -->
<bean id="exampleBean" class="examples.ExampleBean">
    <constructor-arg type="int" value="7500000"/>
    <constructor-arg type="java.lang.String" value="42"/>
</bean>
```

​	**3、参数名**

```xml
<!-- 第三种：直接通过参数名来设置 -->
<bean id="user" class="com.wlp.pojo.user">
    <constructor-arg name="name" value="java" />
</bean>

<!-- 官方案例 -->
<!-- 当属性为一个对象时 -->
<beans>
    <bean id="beanOne" class="x.y.ThingOne">
        <constructor-arg ref="beanTwo"/>
        <constructor-arg ref="beanThree"/>
    </bean>

    <bean id="beanTwo" class="x.y.ThingTwo"/>
    <bean id="beanThree" class="x.y.ThingThree"/>
</beans>
```

```java
public class SimpleMovieLister {

    // the SimpleMovieLister has a dependency on a MovieFinder
    private MovieFinder movieFinder;

    // a constructor so that the Spring container can inject a MovieFinder
    public SimpleMovieLister(MovieFinder movieFinder) {
        this.movieFinder = movieFinder;
    }

    // business logic that actually uses the injected MovieFinder is omitted...
}
```



**总结：在配置文件加载的时候，容器（beans.xml）中管理的对象就已经初始化了**



## 3、[Spring配置](##1、Spring简介)

#### 1、别名

```xml
<!--别名，如果添加了别名，我们也可以使用别名获取到这个对象-->
<alias name="user" alias="userNew" />

```

#### 2、配置

```xml
<!--
        id: bean的唯一标识符，也就是相当于我们的学的对象名
        class：bean对象所对应的全限定名：包名 + 类型
        name：也是别名，而且name可以同时取多个别名可以用空格、分号、逗号隔开
        scope：作用域
     -->
<bean id="user" class="com.wlp.pojo.user" name="user2 u3,u4;u5">
    <constructor-arg name="name" value="java" />
</bean>

```

#### 3、[import](##1、Spring简介)

这个import，一般用于团队开发，他可以将多个配置文件，合成为一个

假设，现在项目中有多个开发，这三个人复制不同的类开发，不同的类需要

注册在不同的bean中，我们可以利用import将所有人的beans.xml和并为一个

-   **applicationContext.xml**

使用的时候，直接使用总的配置就可以了

```xml
<import resource="beans.xml"/>
<import resource="beans2.xml2 "/>
<import resource="beans3.xml3"/>
```

使用的时候，直接使用总的配置就可以了

**内容相同也会被合并 **



## 4、[DI依赖注入](##1、Spring简介)

![image-20210311180721444](G:\各科笔记\Spring笔记\Spring.assets\image-20210311180721444.png)

#### 1、[构造器注入](##1、Spring简介)

```xml
<bean id="user" class="com.wlp.pojo.user">
    <constructor-arg type="java.lang.String" value="java" />  => 需要提供有参构造方法
</bean>
```





#### 2、Set方式注入【重】

​	1、复杂类型

```java
package com.wlp.pojo;

public class  Address {
    private String address;

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }
    
    @Override
    public String toString() {
        return "Address{" +
                "address='" + address + '\'' +
                '}';
    }
}
```

​	2、真实测试对象

```java
public class Student {

    private String name;
    private Address address;
    private String[] books;
    private List<String> hobbys;
    private Map<String,String> card;
    private Set<String> games;
    private String wife;
    private Properties info;
    
    // 省略所有的get与set方法
    
    @Override
    public String toString() {
        return "Student{" +
                "name='" + name + '\'' +
                ", address=" + address.toString() +
                ", books=" + Arrays.toString(books) +
                ", hobbys=" + hobbys +
                ", card=" + card +
                ", games=" + games +
                ", wife='" + wife + '\'' +
                ", info=" + info +
                '}';
    }
}
```

​	3、Spring配置

```java
<?xml version="1.0" encoding="UTF-8"?>
<beans xmlns="http://www.springframework.org/schema/beans"
       xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
       xsi:schemaLocation="http://www.springframework.org/schema/beans http://www.springframework.org/schema/beans/spring-beans.xsd">

    <!-- 设置别名 -->
    <bean id="address" class="com.wlp.pojo.Address" />

    <bean id="student" class="com.wlp.pojo.Student">
        <!-- 第一种：普通注册 values -->
        <property name="name" value="wlp" />

        <!-- 第二种：Bean注入 ref -->
        <property name="address" ref="address" />

        <!-- 第三种：数组注入 ref -->
        <property name="books">
            <array>
                <value>new Game</value>
                <value>奇诺之旅</value>
                <value>喜洋洋</value>
            </array>
        </property>

        <!-- 第四种：list ref -->
        <property name="hobbys">
            <list>
                <value>听歌</value>
                <value>敲代码</value>
            </list>
        </property>

        <!-- 第五种：map ref -->
        <property name="card">
            <map>
                <entry key="分钟" value="213"></entry>
                <entry key="银行卡" value="sdf"></entry>
            </map>
        </property>

        <!-- 第六种：set ref -->
        <property name="games">
            <set>
                <value>猴子塔防</value>
                <value>cf</value>
            </set>
        </property>

        <!-- 第七种：null -->
        <property name="wife">
            <null></null>
        </property>

        <!-- 第八种：Properties  -->
        <property name="info">
            <props>
                <prop key="学号">201911000</prop>
                <prop key="性别">男</prop>
                <prop key="drive">oracle</prop>
            </props>
        </property>

     </bean>
</beans>
```

​	4、**test测试**

```java
import com.wlp.pojo.Student;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * 功能：
 *
 * @author 武乐萍
 * @modifier 武乐萍
 * @date 2021-03-09 21:49
 * @Version V1.0
 */
public class myTest {

    public static void main(String[] args) {

        ApplicationContext context = new ClassPathXmlApplicationContext("beans.xml");

        Student student = (Student) context.getBean("student");
        System.out.println(student.toString());

    }
}

```



#### 3、[扩展方法注入](##1、Spring简介)

我们可以使用p命名空间和c命名空间进行注入

官方解释：

![image-20210310083018351](G:\各科笔记\Spring笔记\Spring.assets\image-20210310083018351.png)

**使用！**

```xml
<?xml version="1.0" encoding="UTF-8"?>
<beans xmlns="http://www.springframework.org/schema/beans"
       xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
       xmlns:p="http://www.springframework.org/schema/p"
       xmlns:c="http://www.springframework.org/schema/c"
       xsi:schemaLocation="http://www.springframework.org/schema/beans http://www.springframework.org/schema/beans/spring-beans.xsd">

    <!-- p命名空间注入，可以直接注入属性的值 property-->
    <bean id="user" class="com.wlp.pojo.User" p:name="神仙" p:age="19" />

    <!--
        c命名空间注入，通过构造器注入：construct-args
        其实体类必须有有参构造方法和无参构造方法
    -->
    <bean id="user2" class="com.wlp.pojo.User" c:age="18" c:name="神仙" />

</beans>
```

**测试**

```java
@Test
public void test2(){
	ApplicationContext context = new ClassPathXmlApplicationContext("beans.xml");
    User user = context.getBean("user2",User.class);
	System.out.println(user);
}
```

**【需要导入的xml约束】**

```xml
<!--
	xmlns:p="http://www.springframework.org/schema/p"
	xmlns:c="http://www.springframework.org/schema/c"
-->
```



#### 5、[Bean的作用域](##1、Spring简介)

![image-20210310090305504](G:\各科笔记\Spring笔记\Spring.assets\image-20210310090305504.png)



##### 1、单例模式（Spring默认机制）

```xml
<bean id="user2" class="com.wlp.pojo.User" c:age="18" c:name="神仙" scope="singleton"/>
```



##### 2、原型模式

**每次从容器中get的时候，都会产生一个新对象**

```xml
<bean id="accountService" class="com.something.DefaultAccountService" scope="prototype"/>
```



##### 3、其他

-   **request、session、application 这些只能在web开发中使用**



## 5、Bean的自动装配

-   自动装配是Spring满足bean依赖的一种方式
-   Spring会在上下文中自动寻找，并自动给bean装配属性！



在Spring中有三种自动装配方式

1.  在xml中显示的配置
2.  在java中显示的配置
3.  隐式的自动装配bean【重】



#### 1、测试

1.  环境搭建
    -   一个人有两个宠物

-   实体：

```java
public class Cat {
    public void shou(){
        System.out.println("喵");
    }
}

public class Dog {

    public void shou(){
        System.out.println("汪");
    }
}

public class People {

    private Cat cat;
    private Dog dog;
    private String name;
    
    public Cat getCat() {
        return cat;
    }

    public void setCat(Cat cat) {
        this.cat = cat;
    }

    public Dog getDog() {
        return dog;
    }

    public void setDog(Dog dog) {
        this.dog = dog;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public String toString() {
        return "People{" +
                "cat=" + cat +
                ", dog=" + dog +
                ", name='" + name + '\'' +
                '}';
    }
}

```

-   配置

```xml
<?xml version="1.0" encoding="UTF-8"?>
<beans xmlns="http://www.springframework.org/schema/beans"
       xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
       xsi:schemaLocation="http://www.springframework.org/schema/beans http://www.springframework.org/schema/beans/spring-beans.xsd">

    <bean id="car" class="com.wlp.pojo.Cat" />
    <bean id="dog" class="com.wlp.pojo.Dog" />

    <bean id="people" class="com.wlp.pojo.People">
        <property name="name" value="神仙" />
        <property name="dog" ref="dog" />
        <property name="cat" ref="car" />
    </bean>
</beans>
```



#### 2、byName自动装配

```xml
<?xml version="1.0" encoding="UTF-8"?>
<beans xmlns="http://www.springframework.org/schema/beans"
       xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
       xsi:schemaLocation="http://www.springframework.org/schema/beans http://www.springframework.org/schema/beans/spring-beans.xsd">

    <bean id="cat" class="com.wlp.pojo.Cat" />
    <bean id="dog" class="com.wlp.pojo.Dog" />


    <!--
        byName: 会自动在容器上下文中查找，和自己对象set方法后面的值对象的beanId
                如果beanId与set方法值不一致会出现空指针异常！
    -->
    <bean id="people" class="com.wlp.pojo.People" autowire="byName">
        <property name="name" value="神仙" />
    </bean>
</beans>
```

#### 3、byType自动装配

```xml
<?xml version="1.0" encoding="UTF-8"?>
<beans xmlns="http://www.springframework.org/schema/beans"
       xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
       xsi:schemaLocation="http://www.springframework.org/schema/beans http://www.springframework.org/schema/beans/spring-beans.xsd">

    <bean id="cat" class="com.wlp.pojo.Cat" />
    <bean id="dog" class="com.wlp.pojo.Dog" />


    <!--
        byName: 会自动在容器上下文中查找，和自己对象set方法后面的值对象的beanId
                如果beanId与set方法值不一致会出现空指针异常！

		byType: 会自动在容器上下文中查找，和自己对象属性类型相同的bean！
				必须保证此类型全局唯一，且不写beanId也可以直接运行
				出现两个类型一致beanId不同的bean会报错！
    -->
    <bean id="people" class="com.wlp.pojo.People" autowire="byType">
        <property name="name" value="神仙" />
    </bean>
</beans>
```



**小结：**

-   byName的时候，需要保证所有**bean的id唯一**，并且此bean需要和
    -   自动注入的属性的set方法的值一致
-   byType的时候，需要保证所有**bean的class唯一**
    -   并且这个bean需要和自动注入的属性类型一致



## 6、注解实现自动装配

**官方文档位置**

![image-20210311203936956](G:\各科笔记\Spring笔记\Spring.assets\image-20210311203936956.png)



**Jdk1.5支持注解，Spring2.5支持注解！**



#### 1、准备工作

-   导入约束

>   xmlns:context="http://www.springframework.org/schema/context"  **=>** **context约束**
>
>   xsi:schemaLocation="http://www.springframework.org/schema/beans
>           https://www.springframework.org/schema/beans/spring-beans.xsd
>           http://www.springframework.org/schema/context
>           https://www.springframework.org/schema/context/spring-context.xsd"  **=> context约束支持**

-   配置注解支持

```xml
<?xml version="1.0" encoding="UTF-8"?>
<beans xmlns="http://www.springframework.org/schema/beans"
    xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
    xmlns:context="http://www.springframework.org/schema/context"
    xsi:schemaLocation="http://www.springframework.org/schema/beans
        https://www.springframework.org/schema/beans/spring-beans.xsd
        http://www.springframework.org/schema/context
        https://www.springframework.org/schema/context/spring-context.xsd">

    <!-- 开启注解支持，没开注解无效！ -->
    <context:annotation-config/>

</beans>
```



#### **2、@Autowired的使用**

**直接在属性上使用即可！ 也可以在set方法上使用**

-   **使用Autowired之后可以 不用编写Set方法，前提是这个自动装配的属性在IOC（Spring）**

-   **容器中存在，且符合名字ByName**

```java
package com.wlp.pojo;

import org.springframework.beans.factory.annotation.Autowired;

/**
 * 功能： 人
 *
 * @author 武乐萍
 * @modifier 武乐萍
 * @date 2021-03-10 10:04
 * @Version V1.0
 */
public class People {

    @Autowired
    private Cat cat;
    @Autowired
    private Dog dog;
    private String name;

    public Cat getCat() {
        return cat;
    }

    @Autowired
    public void setCat(Cat cat) {
        this.cat = cat;
    }

    public Dog getDog() {
        return dog;
    }

    @Autowired
    public void setDog(Dog dog) {
        this.dog = dog;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public String toString() {
        return "People{" +
                "cat=" + cat +
                ", dog=" + dog +
                ", name='" + name + '\'' +
                '}';
    }
}

```

##### **科普**

**@Nullable  字段标签了这个注解，说明这个字段可以为null**

```java
import org.springframework.lang.Nullable;
public class People {

    // 如果显示的定义了Autowired的require为false，
    // 说明这个对象可以为null，否则不允许为空
    @Autowired(required = false)
    private Cat cat;
    
     @Autowired
    public void setCat(@Nullable Cat cat) {
        this.cat = cat;
    }
}
```

>   如果@Autowired自动装配环境比较复杂，自动装配无法通过一个注解【@Autowired】完成的时候，
>
>   我们可以使用@Qualifier(value = "beanId")去配合@Autowired的使用，指定一个唯一的bean对象注入！

```java

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
public class People {    
	@Autowired(required = false)
    private Cat cat;
    @Autowired
    @Qualifier(value = "dog")
    private Dog dog;
}
```

**@Resourse注解  拥有Auotwired和Qualifier的功能**  会根据beanId去自动装配，beanid无效然后根据class装配

```java
public class People {

    // 如果显示的定义了Autowired的require为false，
    // 说明这个对象可以为null，否则不允许为空
    @Resource(name = "cat")
    private Cat cat;
    @Autowired
    @Qualifier(value = "dog")
    private Dog dog;
    private String name;
}
```



**小结：**

-   @Resource和@ Autowired的区别:

    -   都是用来自动装配的，都可以放在属性字段上

    -   @Autowired通过byType的方式实现，而且必须要求这个对象存在！【常用】

    -   @Resource 默认通过byname的方式实现，如果找不到名字，则通过byType实现!

        如果两个都找不到的情况下，就报错!

    -   **执行顺序：@Autowired通过byType的方式实现，@Resource 默认通过byname的方式实现**



## 7、注解开发

#### 1、在spring4之后，使用注解开发，必须要保证aop包的导入

![image-20210311214236281](G:\各科笔记\Spring笔记\Spring.assets\image-20210311214236281.png)

#### 2、导入context约束，增加注解支持



#### 3、编写bean

#### 4、属性如何注入

```java
// 等价于   <bean id="user" class="com.wlp.pojo.User"/>
    //@Component 组件
@Component
public class User {

    public String name = "神仙";

    // 相当于 <property name="name" value="神仙" />
    @Value("神仙")
    public void setName(String name) {
        this.name = name;
    }
}
```



##### 1、衍生的注解

@Component的衍生注解，在web中会按照mvc三层结构分层

-   dao 【@Repository】
-   service 【@Service】
-   controller 【@Controller】

功能都是一样的，都是代表将某个类注册到Spring中，装配bean

##### 2、自动配置配置

>   @Autowired：自动装配通过类型，名字
>
>   ​	如果Autowired不能唯一自动装配上属性，则需要通过@Qualifier
>
>   @Nullable：作用于字段上，说明这个字段可以为null
>
>   @Recource：自动装配通过名字，类型

##### 3、作用域

```java
@Component
@Scope("singleton")
public class User {
    
}
```



#### **4、小结**

​	xml.与注解: 

-   ​	
    -   xml 更加万能，适用于任何场合!维护简单方便
    -   注解不是自己类使用不了，维护相对复杂!

     xml与注解最佳实践:

    -   xml用来管理bean;
    -   注解只负责完成属性的注入;
    -   在使用的过程中，只需要注意一个问题: 必须让注解生效,就需要开启注解的支持





## 8、完全使用java的方式配置Spring

**完全不使用Spring的xml配置，全权交给Java来做**

![](G:\各科笔记\Spring笔记\Spring.assets\image-20210312092409880.png)