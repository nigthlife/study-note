document.querySelector(".google").onclick = function() {
    alert("Google一下")
}